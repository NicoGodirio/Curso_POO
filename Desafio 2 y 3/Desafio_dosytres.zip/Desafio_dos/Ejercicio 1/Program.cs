﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Ejercicio_1
{
    public struct Elemento
    {
        private string ID;
        private double Peso;
        private double Altura;
        

        public Elemento(string iD, double peso, double altura)
        {
            ID = iD;
            Peso = peso;
            Altura = altura;
        }

        public void setID(string ID)
        {
            this.ID = ID;
        }
        public string getID()
        {
            return this.ID;
        }
        public void setPeso(double peso)
        {
            this.Peso = peso;
        }
        public double getPeso()
        {
            return this.Peso;
        }
        public void setAltura(double altura)
        {
            this.Altura = altura;
        }
        public double getAltura()
        {
            return this.Altura;
        }

    }


    internal class Panel
    {
        void iniciar()
        {
            



        }
        void imprimirRecibo(int totalDiario, int totalOperacion)
        {
            Console.WriteLine("Elementos Diarios:"+totalDiario);
            Console.WriteLine("Elementos Ingresados" + totalOperacion);
        }

      

        static void Main(string[] args)// Iniciar

        {
            
            int totalDiario = 5;
            int totalOperacion = 0;
            List<Elemento> elementos = new List<Elemento>();
            string booleano;
            do
            {
                Console.WriteLine("quiere ingresar un elemento?");
                Console.WriteLine("ingrese 'si' para comenzar");
                booleano = Console.ReadLine();
                if (booleano == "si")
                {
                    Elemento e;
                    double altura;
                    double peso;
                    String id;
                    Console.WriteLine("Ingrese ID:");
                    id = Console.ReadLine();
                    Console.WriteLine("Ingrese altura:");
                    altura = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Ingrese peso:");
                    peso = Convert.ToDouble(Console.ReadLine());
                    e = new Elemento(id, peso, altura);
                    elementos.Add(e);
                    totalDiario++;
                    totalOperacion++;
                }
            } while (booleano=="si");
            List <Elemento> vistos = new List<Elemento>();
            /*for (int i = 0; i < elementos.Count; i++)
            {
                int cant = 0;
                if (!vistos.Contains(elementos.ElementAt(i)))
                {

                    for (int j = 0; j < elementos.Count; j++)
                    {
                        if (!vistos.Contains(elementos.ElementAt(j)))
                        {
                            vistos.Add(elementos.ElementAt(j));
                            cant++;
                        }
                        else {
                            if(i!=j)
                            {
                                cant++;
                            }

                        }
                    }

                }
                           
                
            }*/
            foreach (Elemento ele in elementos){
                if (!vistos.Contains(ele)) { 
                    vistos.Add(ele);
                }
            }
            foreach (Elemento ele in vistos) {
                int cant = 0;
                for (int i = 0; i < elementos.Count; i++)
                {
                    if (ele.Equals(elementos[i]))
                    {
                        cant++;
                    }
                }
                Console.WriteLine(ele.getID()+": "+cant);
            }

            Console.ReadKey();











        }
    }
}