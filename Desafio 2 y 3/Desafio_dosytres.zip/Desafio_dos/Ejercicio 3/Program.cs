﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_3
{

    public class Cliente
    {
        private int id;
        private string nombre;
        private string direccion;
        private int telefono;
        private string producto;

        public int getId()
        {
            return id;
        }

        public void setId(int id)
        {
            this.id = id;
        }

        public string getNombre()
        {
            return nombre;
        }

        public void setNombre(string nombre)
        {
            this.nombre = nombre;
        }

        public string getDireccion()
        {
            return direccion;
        }

        public void setDireccion(string direccion)
        {
            this.direccion = direccion;
        }

        public int getTelefono()
        {
            return telefono;
        }

        public void setTelefono(int telefono)
        {
            this.telefono = telefono;
        }

        public string getProducto()
        {
            return producto;
        }

        public void setProducto(string producto)
        {
            this.producto = producto;
        }

        public void extraer()
        {

            int monto;
            int saldo = Cuenta.getSaldo();

            Console.WriteLine("ingrese monto a extraer");
            monto = Convert.ToInt32(Console.ReadLine());

            if (saldo > monto)
            {
                saldo = saldo - monto;
            }
            else
            {
                Console.WriteLine("Saldo insuficiente");
            }
        }

        public void depositar()
        {
            int saldo = Cuenta.getSaldo();
            int monto;
            Console.WriteLine("ingrese monto depositado");

            monto = Convert.ToInt32(Console.ReadLine());
            saldo = saldo + monto;

        }

        public void trasnferir()
        {
            int saldo = Cuenta.getSaldo();
            int monto;
            Console.WriteLine("ingrese monto a transferir");

            monto = Convert.ToInt32(Console.ReadLine());

            if (saldo > monto)
            {
                realizarTrasferencia();
                saldo = saldo - monto;
                Console.WriteLine("Trasferencia Realizada");
            }
            else
            {
                Console.WriteLine("Saldo insuficiente");
            }

        }


    }


    public class FondoInversion
    {
        private string nombre;
        private int importe;
        private int rentabilidad;
        private string fechaApertura;
        private string vencimiento;

        public string getNombre()
        {
            return nombre;
        }

        public void setNombre(string nombre)
        {
            this.nombre = nombre;
        }

        public int getImporte()
        {
            return importe;
        }

        public void setImporte(int importe)
        {
            this.importe = importe;
        }

        public int getRentabilidad()
        {
            return rentabilidad;
        }

        public void setRentabilidad(int rentabilidad)
        {
            this.rentabilidad = rentabilidad;
        }

        public string getFechaApertura()
        {
            return fechaApertura;
        }

        public void setFechaApertura(string fechaApertura)
        {
            this.fechaApertura = fechaApertura;
        }

        public string getVencimiento(string vencimiento)
        {
            return vencimiento;
        }

        public void setVencimiento()
        {
            this.vencimiento = vencimiento;
        }
    }

    public class CarteraValores
    {
        private string nombre;
        private int titulo;
        private int precio;

        public string getNombre()
        {
            return nombre;
        }

        public void setNombre(string nombre)
        {
            this.nombre = nombre;
        }

        public int getTitulo()
        {
            return titulo;
        }

        public void setTitulo(int titulo)
        {
            this.titulo = titulo;
        }

        public int getPrecio()
        {
            return precio;
        }

        public void setPrecio(int precio)
        {
            this.precio = precio;
        }
    }

    public class CajaAhorro : Cliente
    {
        private int plazo;
        private Cliente cliente;

        public int getPlazo()
        {
            return plazo;
        }

        public void setPlazo(int plazo)
        {
            this.plazo = plazo;
        }

        public Cliente getCliente()
        {
            return cliente;
        }

        public void setCliente(Cliente cliente)
        {
            this.cliente = cliente;
        }
    }

    public class TarjetaCredito : Cliente
    {
        private int tipo;
        private int numero;
        private Cliente cliente;
        private int caducidad;

        public int getTipo()
        {
            return tipo;
        }

        public void setTipo(int tipo)
        {
            this.tipo = tipo;
        }

        public int getNumero()
        {
            return numero;
        }

        public void setNumero(int numero)
        {
            this.numero = numero;
        }

        public Cliente getCliente()
        {
            return cliente;
        }

        public void setCliente(Cliente cliente)
        {
            this.cliente = cliente;
        }

        public int getCaducidad()
        {
            return caducidad;
        }

        public void setCaducidad(int caducidad)
        {
            this.caducidad = caducidad;
        }
    }

    public class Cuenta
    {
        private int id;
        private int fechaApertura;
        private int saldo;
        private int tipoIntereses;
        private Cliente cliente;
        private string tipoCuenta;

        public int getId()
        {
            return id;
        }

        public void setId(int id)
        {
            this.id = id;
        }

        public int getFechaApertura()
        {
            return fechaApertura;
        }

        public void setFechaApertura(int fechaApertura)
        {
            this.fechaApertura = fechaApertura;
        }

        public int getSaldo()
        {
            return saldo;
        }

        public void setSaldo(int saldo)
        {
            this.saldo = saldo;
        }

        public int getTipoIntereses()
        {
            return tipoIntereses;
        }

        public void setTipoIntereses(int tipoIntereses)
        {
            this.tipoIntereses = tipoIntereses;
        }

        public Cliente GetCliente()
        {
            return cliente;
        }

        public void setCliente(Cliente cliente)
        {
            this.cliente = cliente;
        }

        public string getTipoCuenta()
        {
            return tipoCuenta;
        }

        public void setTipoCuenta(string tipoCuenta)
        {
            this.tipoCuenta = tipoCuenta;
        }

    }

    public class Banco
    {
        private Cuenta cuenta;
        private Cliente cliente;
        private string producto;

        public Cuenta getCuenta()
        {
            return cuenta;
        }

        public void setCuenta(Cuenta cuenta)
        {
            this.cuenta = cuenta;
        }
        public Cliente GetCliente()
        {
            return cliente;
        }

        public void setCliente(Cliente cliente)
        {
            this.cliente = cliente;
        }

        public string getProducto()
        {
            return producto;
        }

        public void setProducto(string producto)
        {
            this.producto = producto;
        }

        public void altaCliente()
        {
        }
        public void bajaCliente()
        {
        }
        public void modificarCliente()
        {
        }
        public void consultarCliente()
        {
        }

    }
}
