﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_2
{
    public class Persona
    {
        private int dni;
        private string nombre;
        private string direccion;

        public Persona(Persona p)
        {
            dni =p.getDNI();
            nombre = p.getNombre();
            direccion= p.getDireccion();
        }

        public Persona(int dni, string nombre, string direccion)
        {
            this.dni = dni;
            this.nombre = nombre;
            this.direccion = direccion;
        }
        public string getNombre()
        {
            return nombre;
        }

        public void setNombre(string nombre)
        {
            this.nombre = nombre;
        }
        public string getDireccion() {
            return direccion;
        }
        public void setDireccion(string direccion)
        {
            this.direccion = direccion;
        }
        public int getDNI() { 
            return dni; 
        }
        
        public void setDNI(int dni)
        {
            this.dni = dni;
        }

    }
    public class Asignatura
    {
        private string nombre;
        private int cantHoras;
        private string cuatrimestre;
        private string tipo;
        private string estado;

        public Asignatura(string nombre, int cantHoras, string cuatrimestre, string tipo, string estado)
        {
            this.nombre = nombre;
            this.cantHoras = cantHoras;
            this.cuatrimestre = cuatrimestre;
            this.tipo = tipo;
            this.estado = estado;
        }

        public string getNombre()
        {
            return nombre;
        }

        public void setNombre(string nombre)
        {
            this.nombre = nombre;
        }

        public int getcantHoras()
        {
            return cantHoras;
        }

        public void setcantHoras( int horas)
        {
            cantHoras = horas;
        }

        public string getCuatrimestre()
        {
            return cuatrimestre;
        }

        public void setCuatrimestre(string cuatrimestre)
        {
            this.cuatrimestre = cuatrimestre;
        }

        public string getTipo()
        {
            return cuatrimestre;
        }

        public void setTipo(string Tipo)
        {
            this.tipo = Tipo;
        }

        public string getEstado()
        {
            return estado;
        }

        public void setEstado(string Estado)
        {
            this.estado = Estado;
        }

    }
    public class Profesor : Persona
    {
        private string Departamento;

        public Profesor(int dni, string nombre, string direccion, string departamento) : base(dni, nombre, direccion)
        {
            Departamento = departamento;
        }
    }
    public class Alumno : Persona
    {
        private int legajo;
        private Carrera carrera;
        private Asignatura[] enCurso;
        private histAcademico[] Aprobadas;
        private Persona p;

        public int Legajo { get => legajo; set => legajo = value; }

        public Alumno(int dni, string nombre, string direccion) : base(dni, nombre, direccion)
        {
        }

        public Alumno(Persona p) : base(p)
        {
        }

        public void inscribirCarrera(Carrera Carrera)
        {
            carrera= Carrera;
        }

        public void inscribirMateria(Asignatura materia)
        {
            Asignatura[] temp= new Asignatura[enCurso.Length+1];
            int indice = 0;
            foreach (Asignatura asig in enCurso)
            {
                temp[indice++]= asig;
            }
            temp[indice] = materia;
            enCurso= temp;
        }
        public void Aprobar(Asignatura materia,int nota, string fecha)
        {
            if (enCurso.Contains(materia)) {
                if (nota >= 7)
                {
                    histAcademico[] temp = new histAcademico[Aprobadas.Length + 1];
                    int indice = 0;
                    foreach (histAcademico asig in Aprobadas)
                    {
                        temp[indice++] = asig;
                    }
                    temp[indice] = (histAcademico)materia;
                    temp[indice].setNota(nota);
                    temp[indice].setFecha(fecha);
                    enCurso = temp;
                }
            }
        }



    }

    public class histAcademico : Asignatura
    {
        private int nota;
        private string fecha;
        public histAcademico(string nombre, int cantHoras, string cuatrimestre, string tipo, string estado) : base(nombre, cantHoras, cuatrimestre, tipo, estado)
        {

        }

        public void setNota(int Nota)
        {
            this.nota= Nota;
        }
        public int getNota() {
            return nota;
        }
        public string getFecha() {
            return fecha;   
        }
        public void setFecha(string fecha)
        {
            this.fecha= fecha;
        }    
    }
    public class Carrera
    {
        private string sede;
        private Asignatura[] asignatura;

        public Carrera(string Sede, Asignatura[] Asignatura)
        {
           sede = Sede;
           asignatura = Asignatura;
        }
    }

    internal class Sistema
    {
        static void Main(string[] args)
        {
            int cantAlumnos;
            Alumno[] alumnos;
            Carrera[] carreras;
            Profesor[] profesores;
            void alta(Persona p, Carrera c)
            {
                if (!carreras.Contains(c))
                {
                    Console.WriteLine("La carrera no esta disponible");

                }
                else
                {
                    Alumno nuevo = new Alumno(p);
                    foreach (Alumno a in alumnos)
                    {
                        if (nuevo.getDNI() == a.getDNI())
                        {
                            Console.WriteLine(a.getNombre() + "ya esta inscripto en " + c);
                            break;
                        }
                        nuevo.Legajo = a.Legajo + 1;
                    }
                    Alumno[] temp = new Alumno[alumnos.Length + 1];
                    int indice = 0;
                    foreach (Alumno alumno in alumnos)
                    {
                        temp[indice++] = alumno;
                    }
                    nuevo.inscribirCarrera(c);
                    temp[indice] = nuevo;
                    alumnos = temp;
                    Console.WriteLine("Ha sido inscripto");
                }
            }
            void baja(Alumno a) {
                if (alumnos.Contains(a))
                {
                    Alumno[] temp = new Alumno[alumnos.Length - 1];
                    int indice = 0;
                    foreach (Alumno alumno in alumnos)
                    {
                        if (!alumno.Equals(a))
                            temp[indice++] = alumno;
                    }
                    alumnos = temp;
                    Console.WriteLine("Ha sido dado de baja");
                }
            }

        }
        
    }
}
